# CodeClause_Gender-and-age-detection-system
I developed this project using Python  for Predicting gender and age of  a person.
